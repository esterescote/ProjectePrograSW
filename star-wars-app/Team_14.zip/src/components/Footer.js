import React from "react";

function Footer() 
{
  return (
    <footer>
      <p>Star Wars Universe © 2025</p>
      <p>Marina Magí i Ester Martínez</p>
    </footer>
  );
}

export default Footer;
